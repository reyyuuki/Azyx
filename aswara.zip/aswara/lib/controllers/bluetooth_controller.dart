import 'dart:async';
import 'dart:developer';
import 'dart:io';
import 'package:get/get.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';

class BluetoothController extends GetxController {
  final RxList<ScanResult> scanResults = <ScanResult>[].obs;
  final Rx<BluetoothDevice?> connectedDevice = Rx<BluetoothDevice?>(null);
  static final BluetoothController instance = Get.find<BluetoothController>();
  final RxBool isScanning = false.obs;
  final RxBool isConnecting = false.obs;
  final RxString connectingDeviceId = ''.obs;
  final Rx<BluetoothConnectionState> connectionState =
      BluetoothConnectionState.disconnected.obs;
  final Rx<BluetoothAdapterState> adapterState =
      BluetoothAdapterState.unknown.obs;

  StreamSubscription? _scanSubscription;
  StreamSubscription? _adapterSubscription;
  StreamSubscription? _connectionSubscription;

  @override
  void onInit() {
    super.onInit();
    log('BluetoothController initialized');
    _listenToAdapterState();
  }

  void _listenToAdapterState() {
    _adapterSubscription = FlutterBluePlus.adapterState.listen((state) {
      adapterState.value = state;
      log('Bluetooth adapter state changed: $state');
      if (state == BluetoothAdapterState.off) {
        log('Bluetooth is OFF. Requesting user to enable it.');
      } else if (state == BluetoothAdapterState.on) {
        log('Bluetooth is ON. Ready to scan.');
      }
    });
  }

  String getDeviceName(ScanResult result) {
    if (result.advertisementData.localName.isNotEmpty) {
      return result.advertisementData.localName;
    }
    if (result.device.platformName.isNotEmpty) {
      return result.device.platformName;
    }
    if (result.device.advName.isNotEmpty) {
      return result.device.advName;
    }
    return "Unknown Device";
  }

  Future<bool> requestPermissions() async {
    log('Requesting permissions...');
    if (Platform.isAndroid) {
      final androidInfo = await DeviceInfoPlugin().androidInfo;
      final sdkInt = androidInfo.version.sdkInt;
      log('Android SDK Version: $sdkInt');

      if (sdkInt >= 31) {
        Map<Permission, PermissionStatus> statuses = await [
          Permission.bluetoothScan,
          Permission.bluetoothConnect,
          Permission.location,
        ].request();

        bool btGranted =
            (statuses[Permission.bluetoothScan]?.isGranted ?? false) &&
            (statuses[Permission.bluetoothConnect]?.isGranted ?? false);
        bool locGranted = statuses[Permission.location]?.isGranted ?? false;

        log('Android 12+ BT Permissions: $btGranted, Location: $locGranted');

        if (!locGranted) {
          log(
            'Location permission denied on Android 12+. Scanning capabilities might be limited.',
          );
        }

        return btGranted;
      } else {
        Map<Permission, PermissionStatus> statuses = await [
          Permission.location,
          Permission.locationWhenInUse,
          Permission.bluetooth,
          Permission.bluetoothScan,
          Permission.bluetoothConnect,
        ].request();

        bool granted =
            (statuses[Permission.location]?.isGranted ?? false) ||
            (statuses[Permission.locationWhenInUse]?.isGranted ?? false);
        log('Android <12 permissions granted: $granted');

        var locationStatus = await Permission.location.serviceStatus;
        if (!locationStatus.isEnabled) {
          log(
            'Location service (GPS) is disabled. It is REQUIRED for scanning on Android.',
          );
          return false;
        }

        return granted;
      }
    }
    log('Permissions granted (iOS/Other)');
    return true;
  }

  Future<bool> ensureBluetoothEnabled() async {
    log('Ensuring Bluetooth is enabled...');
    if (adapterState.value == BluetoothAdapterState.unknown) {
      try {
        await FlutterBluePlus.adapterState
            .firstWhere((state) => state != BluetoothAdapterState.unknown)
            .timeout(const Duration(seconds: 3));
      } catch (e) {
        log('Timeout waiting for adapter state: $e');
        return false;
      }
    }

    if (adapterState.value != BluetoothAdapterState.on) {
      if (Platform.isAndroid) {
        try {
          log('Attempting to turn on Bluetooth (Android)...');
          await FlutterBluePlus.turnOn();
          await FlutterBluePlus.adapterState
              .firstWhere((state) => state == BluetoothAdapterState.on)
              .timeout(const Duration(seconds: 5));
          log('Bluetooth turned on successfully');
          return true;
        } catch (e) {
          log('Failed to turn on Bluetooth: $e');
          return false;
        }
      } else {
        log('Bluetooth is off. User must enable it manually on iOS.');
        return false;
      }
    }
    return true;
  }

  Future<void> startScan() async {
    log('Attempting to start scan...');
    if (isScanning.value) {
      log('Already scanning. Aborting new scan request.');
      return;
    }

    try {
      await FlutterBluePlus.stopScan();
      scanResults.clear();

      bool permGranted = await requestPermissions();
      if (!permGranted) {
        log('Permissions denied or Location services disabled.');
        throw Exception('Permissions denied or Location services disabled');
      }

      bool btEnabled = await ensureBluetoothEnabled();
      if (!btEnabled) {
        log('Bluetooth disabled.');
        throw Exception('Bluetooth disabled');
      }

      var locService = await Permission.location.serviceStatus;
      if (Platform.isAndroid && !locService.isEnabled) {
        log(
          'WARNING: GPS is disabled. Android scans often fail without GPS enabled.',
        );
      }

      isScanning.value = true;
      log('Starting scan subscription...');

      _scanSubscription = FlutterBluePlus.scanResults.listen(
        (results) {
          scanResults.value = results;
          for (var r in results) {
            String deviceName = getDeviceName(r);
            log('---------------------------------------------------');
            log('Device Found: $deviceName');
            log('Original Platform Name: ${r.device.platformName}');
            log('Original Adv Name: ${r.device.advName}');
            log('Local Name: ${r.advertisementData.localName}');
            log('ID: ${r.device.remoteId}');
            log('RSSI: ${r.rssi}');
            log('Services: ${r.advertisementData.serviceUuids}');
            log('Connectable: ${r.advertisementData.connectable}');
            log('---------------------------------------------------');
          }
          log('Total devices found so far: ${results.length}');
        },
        onError: (e) {
          log('Error during scan stream: $e');
          isScanning.value = false;
        },
      );

      // ✅ KEY CHANGE: Set androidUsesFineLocation to true
      await FlutterBluePlus.startScan(
        timeout: const Duration(seconds: 30),
        androidUsesFineLocation: true, // Changed from false to true
        continuousUpdates: true,
      );

      await FlutterBluePlus.isScanning.where((val) => val == false).first;
      log('Scan finished naturally.');
      isScanning.value = false;
    } catch (e, stackTrace) {
      isScanning.value = false;
      log('CRITICAL ERROR during scan: $e');
      log('Stack trace: $stackTrace');
    }
  }

  Future<void> stopScan() async {
    log('Stopping scan manually...');
    try {
      await FlutterBluePlus.stopScan();
      _scanSubscription?.cancel();
      isScanning.value = false;
      log('Scan stopped.');
    } catch (e, stackTrace) {
      log('Error stopping scan: $e');
      log('Stack trace: $stackTrace');
    }
  }

  Future<bool> connectToDevice(BluetoothDevice device) async {
    log(
      'Attempting to connect to: ${device.remoteId} (${device.platformName})',
    );
    isConnecting.value = true;
    connectingDeviceId.value = device.remoteId.toString();

    try {
      await stopScan();

      _connectionSubscription = device.connectionState.listen((state) {
        connectionState.value = state;
        log('Connection state for ${device.remoteId}: $state');
        if (state == BluetoothConnectionState.disconnected) {
          log('Device disconnected: ${device.remoteId}');
          connectedDevice.value = null;
        } else if (state == BluetoothConnectionState.connected) {
          log('Device connected: ${device.remoteId}');
          connectedDevice.value = device;
        }
      });

      await device.connect(
        timeout: const Duration(seconds: 20),
        autoConnect: false,
        license: License.free,
      );

      if (Platform.isAndroid) {
        log('Requesting MTU 512...');
        await device.requestMtu(512);
        log('MTU request sent');
      }

      log('Discovering services...');
      List<BluetoothService> services = await device.discoverServices();
      log('Services discovered: ${services.length}');
      for (var s in services) {
        log('Service UUID: ${s.uuid}');
      }

      String deviceName = device.platformName.isNotEmpty
          ? device.platformName
          : device.advName.isNotEmpty
          ? device.advName
          : "Unknown Device";

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('device_id', device.remoteId.toString());
      await prefs.setString('device_name', deviceName);
      await prefs.setBool('onboarding_completed', true);
      log('Device details saved to SharedPreferences');

      isConnecting.value = false;
      connectingDeviceId.value = '';
      return true;
    } catch (e) {
      log('Failed to connect: $e');
      isConnecting.value = false;
      connectingDeviceId.value = '';
      return false;
    }
  }

  @override
  void onClose() {
    log('BluetoothController closing...');
    stopScan();
    _scanSubscription?.cancel();
    _adapterSubscription?.cancel();
    _connectionSubscription?.cancel();
    super.onClose();
  }
}
