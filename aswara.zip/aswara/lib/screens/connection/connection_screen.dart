import 'package:aswara/constants/colors.dart';
import 'package:aswara/controllers/bluetooth_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

class ConnectionScreen extends StatefulWidget {
  const ConnectionScreen({super.key});

  @override
  State<ConnectionScreen> createState() => _ConnectionScreenState();
}

class _ConnectionScreenState extends State<ConnectionScreen> {
  final BluetoothController controller = Get.find<BluetoothController>();
  RxBool _isInitializing = true.obs;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _initBluetooth();
  }

  Future<void> _initBluetooth() async {
    if (!mounted) return;
    setState(() {
      _isInitializing.value = true;
      _errorMessage = '';
    });

    try {
      if (!await FlutterBluePlus.isSupported) {
        if (!mounted) return;
        setState(() {
          _errorMessage = 'Bluetooth is not supported on this device';
          _isInitializing.value = false;
        });
        return;
      }

      final hasPermissions = await controller.requestPermissions();
      if (!hasPermissions) {
        if (!mounted) return;
        setState(() {
          _errorMessage = 'Bluetooth permissions are required.';
          _isInitializing.value = false;
        });
        return;
      }

      final isEnabled = await controller.ensureBluetoothEnabled();
      if (!isEnabled) {
        if (!mounted) return;
        setState(() {
          _errorMessage = 'Bluetooth must be enabled.';
          _isInitializing.value = false;
        });
        return;
      }

      if (!mounted) return;
      setState(() {
        _isInitializing.value = false;
      });

      await _startScanning();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Error initializing Bluetooth: $e';
        _isInitializing.value = false;
      });
    }
  }

  Future<void> _startScanning() async {
    setState(() {
      _errorMessage = '';
    });
    try {
      await controller.startScan();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = e.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        title: const Text('Connect Device'),
        backgroundColor: AppTheme.primaryColor,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [AppTheme.primaryColor, AppTheme.primaryDark],
              ),
            ),
            child: Column(
              children: [
                Obx(() {
                  final scanning = controller.isScanning.value;
                  return Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      shape: BoxShape.circle,
                    ),
                    child: _isInitializing.value || scanning
                        ? const Padding(
                            padding: EdgeInsets.all(20.0),
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 3,
                            ),
                          )
                        : const Icon(
                            Icons.bluetooth_searching,
                            size: 50,
                            color: Colors.white,
                          ),
                  );
                }),
                const SizedBox(height: 20),
                Obx(
                  () => Text(
                    _isInitializing.value
                        ? 'Initializing...'
                        : controller.isScanning.value
                        ? 'Scanning for devices...'
                        : 'Available Devices',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (_errorMessage.isNotEmpty)
            Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.errorColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.errorColor),
              ),
              child: Row(
                children: [
                  const Icon(Icons.error_outline, color: AppTheme.errorColor),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _errorMessage,
                          style: const TextStyle(color: AppTheme.errorColor),
                        ),
                        const SizedBox(height: 8),
                        TextButton(
                          onPressed: _initBluetooth,
                          style: TextButton.styleFrom(
                            padding: EdgeInsets.zero,
                            minimumSize: const Size(0, 30),
                          ),
                          child: const Text('Try Again'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          Expanded(
            child: _isInitializing.value
                ? const Center(child: CircularProgressIndicator())
                : Obx(() {
                    if (controller.scanResults.isEmpty) {
                      return _buildEmptyState();
                    }

                    return ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: controller.scanResults.length,
                      itemBuilder: (context, index) {
                        final result = controller.scanResults[index];
                        return _buildDeviceCard(result.device, result.rssi);
                      },
                    );
                  }),
          ),
        ],
      ),
      floatingActionButton: Obx(() {
        final scanning = controller.isScanning.value;
        return !scanning && !_isInitializing.value
            ? FloatingActionButton.extended(
                onPressed: _startScanning,
                backgroundColor: AppTheme.primaryColor,
                icon: const Icon(Icons.refresh),
                label: const Text('Scan'),
              )
            : const SizedBox();
      }),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.bluetooth_disabled, size: 64, color: Colors.grey[400]),
          const SizedBox(height: 16),
          Obx(
            () => Text(
              controller.isScanning.value ? 'Searching...' : 'No devices found',
              style: TextStyle(fontSize: 18, color: Colors.grey[600]),
            ),
          ),
          const SizedBox(height: 24),
          Obx(() {
            return !controller.isScanning.value
                ? ElevatedButton.icon(
                    onPressed: _startScanning,
                    icon: const Icon(Icons.refresh),
                    label: const Text('Scan Again'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primaryColor,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 12,
                      ),
                    ),
                  )
                : const SizedBox.shrink();
          }),
        ],
      ),
    );
  }

  Widget _buildDeviceCard(BluetoothDevice device, int rssi) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: AppTheme.primaryColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(
            Icons.watch,
            color: AppTheme.primaryColor,
            size: 28,
          ),
        ),
        title: Text(
          device.platformName.isEmpty ? 'Unknown Device' : device.platformName,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text(
              device.remoteId.toString(),
              style: TextStyle(fontSize: 12, color: Colors.grey[600]),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(
                  Icons.signal_cellular_alt,
                  size: 16,
                  color: _getSignalColor(rssi),
                ),
                const SizedBox(width: 4),
                Text(
                  '$rssi dBm',
                  style: TextStyle(fontSize: 12, color: _getSignalColor(rssi)),
                ),
              ],
            ),
          ],
        ),
        trailing: Obx(() {
          final connectingId = controller.connectingDeviceId.value;
          final isConn = controller.isConnecting.value;
          final isThisDevice = connectingId == device.remoteId.toString();

          return isConn && isThisDevice
              ? const SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      AppTheme.primaryColor,
                    ),
                  ),
                )
              : ElevatedButton(
                  onPressed: () => _connectDevice(device),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryColor,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text('Connect'),
                );
        }),
      ),
    );
  }

  Color _getSignalColor(int rssi) {
    if (rssi >= -60) return Colors.green;
    if (rssi >= -70) return Colors.orange;
    return Colors.red;
  }

  Future<void> _connectDevice(BluetoothDevice device) async {
    final success = await controller.connectToDevice(device);
    if (success) {
      // Get.offNamed('/dashboard');
      Get.snackbar(
        'Connected',
        'Successfully connected to ${device.platformName.isEmpty ? 'device' : device.platformName}.',
        backgroundColor: AppTheme.primaryColor,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
      );
    } else {
      Get.snackbar(
        'Connection Failed',
        'Failed to connect. Please try again.',
        backgroundColor: AppTheme.errorColor,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
      );
    }
  }

  @override
  void dispose() {
    controller.stopScan();
    super.dispose();
  }
}
