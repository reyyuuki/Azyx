class Assets {
  static const String appIcon = 'assets/Logo/Favicon/app_icon.png';
}
