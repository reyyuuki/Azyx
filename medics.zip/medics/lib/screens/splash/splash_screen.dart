import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:medics/constant/colors.dart';
import 'package:medics/constant/assets.dart';
import 'package:medics/controllers/auth_controller.dart';
import 'package:medics/screens/login/login_page.dart';
import 'package:medics/screens/nav_screen/nav_screen.dart';
import 'package:medics/widgets/custom_text.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.6, curve: Curves.easeOutBack),
      ),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.5, curve: Curves.easeIn),
      ),
    );

    _controller.forward();

    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        log('Logged in: ${AuthController.instance.loggedIn.value}');
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (context) => AuthController.instance.loggedIn.value
                ? const NavScreen()
                : const LoginPage(),
          ),
        );
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primary,
      body: Center(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: ScaleTransition(
            scale: _scaleAnimation,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(Assets.logo, width: 150, height: 150),
                const SizedBox(height: 24),
                CustomText.bold(
                  'SahAI',
                  fontSize: 48,
                  color: AppColors.surface,
                  letterSpacing: -1,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
