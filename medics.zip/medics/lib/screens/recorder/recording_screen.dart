import 'dart:async';
import 'dart:developer' as show;
import 'dart:io';
import 'dart:math';
import 'dart:developer' as l;
import 'package:flutter/material.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:medics/models/recording.dart';
import 'package:medics/widgets/custom_text.dart';
import 'package:medics/widgets/visualizer.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:intl/intl.dart';
import 'package:medics/constant/colors.dart';

class RecorderScreen extends StatefulWidget {
  final String patientName;
  final String patientMRN;

  const RecorderScreen({
    super.key,
    required this.patientName,
    required this.patientMRN,
  });

  @override
  State<RecorderScreen> createState() => _RecorderScreenState();
}

enum RecorderPhase { idle, recording, paused, saving }

class _RecorderScreenState extends State<RecorderScreen>
    with TickerProviderStateMixin {
  FlutterSoundRecorder? _recorder;
  FlutterSoundPlayer? _player;
  RecorderPhase _phase = RecorderPhase.idle;
  Duration _duration = Duration.zero;
  Timer? _timer;
  final List<double> _amplitudes = List.filled(50, 0.0);
  StreamSubscription? _recSub;
  String? _currentPath;
  Box<dynamic>? _box;

  double _saveProgress = 0.0;
  late AnimationController _saveCtrl;

  @override
  void initState() {
    super.initState();
    _saveCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..addListener(() => setState(() => _saveProgress = _saveCtrl.value));
    _initRecorder();
    _initHive();
  }

  Future<void> _initHive() async {
    _box = await Hive.openBox<dynamic>('recordings_${widget.patientMRN}');
    setState(() {});
  }

  Future<void> _initRecorder() async {
    _recorder = FlutterSoundRecorder();
    _player = FlutterSoundPlayer();
    await _recorder!.openRecorder();
    await _player!.openPlayer();

    final status = await Permission.microphone.request();
    if (!status.isGranted && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Microphone permission required')),
      );
    }
  }

  Future<void> _start() async {
    final dir = await getApplicationDocumentsDirectory();
    final ts = DateTime.now().millisecondsSinceEpoch;
    _currentPath = '${dir.path}/rec_$ts.aac';

    await _recorder!.startRecorder(toFile: _currentPath, codec: Codec.aacADTS);
    setState(() => _phase = RecorderPhase.recording);

    _duration = Duration.zero;
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() => _duration += const Duration(seconds: 1));
    });
    _listenAmplitude();
  }

  void _listenAmplitude() {
    _recSub?.cancel();

    // ---- NEW: Use onProgress (the ONLY reliable source) ----
    _recSub = _recorder!.onProgress!.listen((e) {
      // e.decibels is null when silent → treat as -160 dB
      final db = e.decibels ?? -160.0;

      // Convert dB → 0-1 (smooth, Siri-like response)
      final normalized = ((db + 50) / 50).clamp(0.0, 1.0);

      if (mounted) {
        setState(() {
          _amplitudes.removeAt(0);
          _amplitudes.add(normalized);
        });
      }
    });
  }

  Future<void> _pause() async {
    await _recorder!.pauseRecorder();
    _timer?.cancel();
    _recSub?.cancel();
    setState(() => _phase = RecorderPhase.paused);
  }

  Future<void> _resume() async {
    await _recorder!.resumeRecorder();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() => _duration += const Duration(seconds: 1));
    });
    _listenAmplitude();
    setState(() => _phase = RecorderPhase.recording);
  }

  Future<void> _saveRecording() async {
    if (_currentPath == null) return;

    await _stopRecording();

    setState(() => _phase = RecorderPhase.saving);
    _saveCtrl.forward(from: 0);

    try {
      show.log(
        'Saving recording... ${widget.patientName} ${widget.patientMRN}',
      );
      final rec = Recording(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        filePath: _currentPath!,
        duration: _duration,
        timestamp: DateTime.now(),
        patientName: widget.patientName,
        patientMRN: widget.patientMRN,
        title:
            'Recording ${DateFormat('MMM dd, HH:mm').format(DateTime.now())}',
      );

      await rec.generateUploadUrl();
      await rec.uploadRecording();
      await _box?.add(rec.toMap());

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Recording saved and uploaded successfully'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      l.log(e.toString());
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      _saveCtrl.reset();
      if (mounted) {
        setState(() {
          _phase = RecorderPhase.idle;
          _duration = Duration.zero;
          _amplitudes.fillRange(0, _amplitudes.length, 0.0);
          _currentPath = null;
        });
      }
    }
  }

  Future<void> _stopRecording() async {
    _timer?.cancel();
    _timer = null;

    _recSub?.cancel();
    _recSub = null;

    if (_recorder?.isRecording ?? false) {
      await _recorder!.stopRecorder();
    }
  }

  Future<void> _discardRecording() async {
    await _stopRecording();

    if (_currentPath != null) {
      try {
        await File(_currentPath!).delete();
      } catch (e) {
        l.log('Error deleting file: $e');
      }
    }
    if (mounted) {
      setState(() {
        _phase = RecorderPhase.idle;
        _duration = Duration.zero;
        _amplitudes.fillRange(0, _amplitudes.length, 0.0);
        _currentPath = null;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _header(),
            Expanded(child: _body()),
          ],
        ),
      ),
    );
  }

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: const Icon(
                Icons.arrow_back_ios_new,
                size: 20,
                color: AppColors.textPrimary,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.patientName,
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary,
                  ),
                ),
                Text(
                  'MRN: ${widget.patientMRN}',
                  style: const TextStyle(
                    fontSize: 13,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _body() {
    switch (_phase) {
      case RecorderPhase.idle:
        return _idleView();
      case RecorderPhase.recording:
        return _recordingView();
      case RecorderPhase.saving:
        return _savingView();
      case RecorderPhase.paused:
        return _recordingView();
    }
  }

  Widget _idleView() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CustomText.bold(
            'Tap to start to syncronise with AI',

            fontSize: 30,
            color: AppColors.textPrimary,

            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          CustomText.regular(
            'Tap the mic to start',
            fontSize: 16,
            color: AppColors.textSecondary,
          ),
          const SizedBox(height: 56),
          SizedBox(
            width: 300,
            height: 300,
            child: Stack(
              alignment: Alignment.center,
              children: [
                VoiceVisualizer(amplitudes: _amplitudes, isRecording: false),
                GestureDetector(
                  onTap: _start,
                  child: Container(
                    width: 92,
                    height: 92,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        colors: [AppColors.primary, Color(0xFF00D9FF)],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.primary.withOpacity(0.4),
                          blurRadius: 28,
                          spreadRadius: 4,
                        ),
                      ],
                    ),
                    child: const Icon(Icons.mic, color: Colors.white, size: 44),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _recordingView() {
    return SingleChildScrollView(
      child: Column(
        children: [
          const SizedBox(height: 32),
          const Text(
            'Recording…',
            style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 40),
          SizedBox(
            height: 360,
            child: Stack(
              alignment: Alignment.center,
              children: [
                VoiceVisualizer(amplitudes: _amplitudes, isRecording: true),
                CustomText.bold(
                  _format(_duration),
                  fontSize: 48,
                  color: AppColors.primary,
                ),
              ],
            ),
          ),
          const SizedBox(height: 48),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 48),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _btn(
                  Icons.stop_rounded,
                  Colors.redAccent,
                  () => _saveRecording(),
                ),
                _btn(
                  _phase == RecorderPhase.recording
                      ? Icons.pause_rounded
                      : Icons.play_arrow_rounded,
                  AppColors.primary,
                  _phase == RecorderPhase.recording ? _pause : _resume,
                  size: 80,
                ),
                _btn(
                  Icons.delete_outline_rounded,
                  Colors.grey[700]!,
                  () => _discardRecording(),
                  size: 68,
                ),
              ],
            ),
          ),
          const SizedBox(height: 48),
        ],
      ),
    );
  }

  Widget _savingView() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text(
            'Saving your recording…',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w600,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 56),
          SizedBox(
            width: 180,
            height: 180,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 180,
                  height: 180,
                  child: CircularProgressIndicator(
                    value: _saveProgress,
                    strokeWidth: 14,
                    backgroundColor: AppColors.surface,
                    valueColor: AlwaysStoppedAnimation(AppColors.primary),
                  ),
                ),
                Text(
                  '${(_saveProgress * 100).toInt()}%',
                  style: const TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.w800,
                    color: AppColors.primary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _btn(
    IconData icon,
    Color color,
    VoidCallback onTap, {
    double size = 70,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.45),
              blurRadius: 24,
              spreadRadius: 3,
            ),
          ],
        ),
        child: Icon(icon, color: Colors.white, size: size * 0.46),
      ),
    );
  }

  String _format(Duration d) {
    final h = d.inHours.toString().padLeft(2, '0');
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return h == '00' ? '$m:$s' : '$h:$m:$s';
  }

  @override
  void dispose() {
    _timer?.cancel();
    _recSub?.cancel();
    _recorder?.closeRecorder();
    _player?.closePlayer();
    _saveCtrl.dispose();
    super.dispose();
  }
}
