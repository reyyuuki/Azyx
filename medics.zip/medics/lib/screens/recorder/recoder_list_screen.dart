import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:medics/models/recording.dart';
import 'package:medics/screens/recorder/recording_screen.dart';
import 'package:medics/widgets/custom_text.dart';
import 'package:medics/constant/colors.dart';
import 'package:intl/intl.dart';

class RecordingsListScreen extends StatefulWidget {
  final String patientName;
  final String patientMRN;

  const RecordingsListScreen({
    super.key,
    required this.patientName,
    required this.patientMRN,
  });

  @override
  State<RecordingsListScreen> createState() => _RecordingsListScreenState();
}

class _RecordingsListScreenState extends State<RecordingsListScreen> {
  FlutterSoundPlayer? _player;
  Box<dynamic>? _recordingsBox;

  @override
  void initState() {
    super.initState();
    _player = FlutterSoundPlayer();
    _player!.openPlayer();
    _openBox();
  }

  Future<void> _openBox() async {
    _recordingsBox = await Hive.openBox<dynamic>(
      'recordings_${widget.patientMRN}',
    );
    setState(() {});
  }

  Future<void> _playRecording(Recording recording) async {
    try {
      if (_player!.isPlaying) await _player!.stopPlayer();
      await _player!.startPlayer(
        fromURI: recording.filePath,
        whenFinished: () => setState(() {}),
      );
      setState(() {});
    } catch (e) {
      _showError('Failed to play recording: $e');
    }
  }

  Future<void> _deleteRecording(int index) async {
    final recordingMap = _recordingsBox!.getAt(index) as Map<dynamic, dynamic>;
    final recording = Recording.fromMap(recordingMap);

    final file = File(recording.filePath);
    if (await file.exists()) await file.delete();
    await _recordingsBox!.deleteAt(index);
    setState(() {});
  }

  Future<void> _renameRecording(int index) async {
    final recordingMap = _recordingsBox!.getAt(index) as Map<dynamic, dynamic>;
    final recording = Recording.fromMap(recordingMap);
    final controller = TextEditingController(text: recording.title);

    final newTitle = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        backgroundColor: AppColors.surface,
        title: CustomText.bold(
          'Rename Recording',
          color: AppColors.textPrimary,
        ),
        content: TextField(
          controller: controller,
          style: TextStyle(color: AppColors.textPrimary),
          decoration: InputDecoration(
            hintText: 'Enter new name',
            hintStyle: TextStyle(color: AppColors.textSecondary),
            filled: true,
            fillColor: AppColors.background,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: CustomText.medium('Cancel', color: AppColors.textSecondary),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, controller.text),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Text('Save'),
          ),
        ],
      ),
    );

    if (newTitle != null && newTitle.isNotEmpty) {
      final updated = Recording(
        id: recording.id,
        filePath: recording.filePath,
        duration: recording.duration,
        timestamp: recording.timestamp,
        patientName: recording.patientName,
        patientMRN: recording.patientMRN,
        title: newTitle,
      );
      await _recordingsBox!.putAt(index, updated.toMap());
      setState(() {});
    }
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  void dispose() {
    _player?.closePlayer();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            Expanded(child: _buildList()),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 20,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Icon(
                Icons.arrow_back_ios_new,
                color: AppColors.textPrimary,
                size: 20,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomText.bold(
                  widget.patientName,
                  fontSize: 18,
                  color: AppColors.textPrimary,
                ),
                CustomText.regular(
                  'MRN: ${widget.patientMRN}',
                  fontSize: 13,
                  color: AppColors.textSecondary,
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (_) => RecorderScreen(
                  patientName: widget.patientName,
                  patientMRN: widget.patientMRN,
                ),
              ),
            ),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    AppColors.primary,
                    AppColors.primary.withOpacity(0.7),
                  ],
                ),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primary.withOpacity(0.4),
                    blurRadius: 15,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: const Icon(Icons.mic, color: Colors.white, size: 24),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildList() {
    if (_recordingsBox == null)
      return const Center(child: CircularProgressIndicator());

    return ValueListenableBuilder(
      valueListenable: _recordingsBox!.listenable(),
      builder: (context, Box<dynamic> box, _) {
        if (box.isEmpty) {
          return Center(
            child: CustomText.regular(
              'No recordings yet',
              fontSize: 16,
              color: AppColors.textSecondary,
            ),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: box.length,
          itemBuilder: (context, index) {
            final recordingMap = box.getAt(index) as Map<dynamic, dynamic>;
            final recording = Recording.fromMap(recordingMap);
            final isPlaying = _player!.isPlaying;

            return Container(
              margin: const EdgeInsets.only(bottom: 14),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 20,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => _playRecording(recording),
                    child: Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [
                            AppColors.primary,
                            AppColors.primary.withOpacity(0.7),
                          ],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.primary.withOpacity(0.3),
                            blurRadius: 12,
                          ),
                        ],
                      ),
                      child: Icon(
                        isPlaying
                            ? Icons.stop_rounded
                            : Icons.play_arrow_rounded,
                        color: Colors.white,
                        size: 26,
                      ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomText.semiBold(
                          recording.title,
                          fontSize: 15,
                          color: AppColors.textPrimary,
                        ),
                        const SizedBox(height: 4),
                        CustomText.regular(
                          '${_formatDuration(recording.duration)} • ${DateFormat('MMM dd, yyyy').format(recording.timestamp)}',
                          fontSize: 12,
                          color: AppColors.textSecondary,
                        ),
                      ],
                    ),
                  ),
                  PopupMenuButton(
                    color: AppColors.surface,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                    itemBuilder: (context) => [
                      PopupMenuItem(
                        onTap: () => Future.delayed(
                          Duration.zero,
                          () => _renameRecording(index),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.edit_outlined,
                              size: 20,
                              color: AppColors.primary,
                            ),
                            const SizedBox(width: 12),
                            CustomText.medium(
                              'Rename',
                              color: AppColors.textPrimary,
                            ),
                          ],
                        ),
                      ),
                      PopupMenuItem(
                        onTap: () => _deleteRecording(index),
                        child: const Row(
                          children: [
                            Icon(
                              Icons.delete_outline,
                              size: 20,
                              color: Colors.red,
                            ),
                            SizedBox(width: 12),
                            Text('Delete', style: TextStyle(color: Colors.red)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final hours = twoDigits(duration.inHours);
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));
    return hours == '00' ? '$minutes:$seconds' : '$hours:$minutes:$seconds';
  }
}
