import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:iconly/iconly.dart';
import 'package:medics/constant/colors.dart';
import 'package:medics/controllers/auth_controller.dart';
import 'package:medics/models/patient.dart';
import 'package:medics/screens/recorder/recording_screen.dart';
import 'package:medics/service/api_service.dart';
import 'package:medics/widgets/custom_text.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String _searchQuery = '';
  String _filterCriteria = 'All';
  List<Patient> _patients = [];
  bool _isLoading = true;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _loadPatients();
  }

  Future<void> _loadPatients() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      final response = await ApiService.fetchPatientList(
        hospitalID: AuthController.instance.hospitalId.value,
        doctorID: AuthController.instance.doctorId.value,
      );

      setState(() {
        _patients = response;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to load patients: $e';
        _isLoading = false;
      });
    }
  }

  List<Patient> get _filteredPatients {
    return _patients.where((patient) {
      final matchesSearch =
          patient.userName.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          patient.mrn.toLowerCase().contains(_searchQuery.toLowerCase());

      if (_filterCriteria == 'All') return matchesSearch;
      if (_filterCriteria == 'Male') {
        return matchesSearch && patient.sex == 'M';
      }
      if (_filterCriteria == 'Female') {
        return matchesSearch && patient.sex == 'F';
      }
      return matchesSearch;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: _isLoading
            ? Center(child: CircularProgressIndicator(color: AppColors.primary))
            : _errorMessage.isNotEmpty
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.error_outline, size: 64, color: Colors.red),
                    const SizedBox(height: 16),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: CustomText.medium(
                        _errorMessage,
                        fontSize: 14,
                        color: AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: _loadPatients,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 24,
                          vertical: 12,
                        ),
                      ),
                      child: CustomText.semiBold(
                        'Retry',
                        fontSize: 14,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              )
            : CustomScrollView(
                slivers: [
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  CustomText.bold(
                                    'Patient Care',
                                    fontSize: 28,
                                    color: AppColors.textPrimary,
                                  ),
                                  const SizedBox(height: 4),
                                  CustomText.regular(
                                    'Manage your patients efficiently',
                                    fontSize: 14,
                                    color: AppColors.textSecondary,
                                  ),
                                ],
                              ),
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: AppColors.primary.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Icon(
                                  IconlyBold.notification,
                                  color: AppColors.primary,
                                  size: 24,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 24),
                          Container(
                            decoration: BoxDecoration(
                              color: AppColors.surface,
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.04),
                                  blurRadius: 20,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: TextField(
                              onChanged: (value) =>
                                  setState(() => _searchQuery = value),
                              decoration: InputDecoration(
                                hintText: 'Search patients...',
                                hintStyle: TextStyle(
                                  color: AppColors.textSecondary,
                                  fontSize: 15,
                                ),
                                prefixIcon: Icon(
                                  IconlyLight.search,
                                  color: AppColors.textSecondary,
                                ),
                                border: InputBorder.none,
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 20,
                                  vertical: 16,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              children: [
                                _buildFilterChip('All', _patients.length),
                                const SizedBox(width: 12),
                                _buildFilterChip(
                                  'Male',
                                  _patients.where((p) => p.sex == 'M').length,
                                ),
                                const SizedBox(width: 12),
                                _buildFilterChip(
                                  'Female',
                                  _patients.where((p) => p.sex == 'F').length,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 24),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText.semiBold(
                                'Patient List',
                                fontSize: 18,
                                color: AppColors.textPrimary,
                              ),
                              CustomText.medium(
                                '${_filteredPatients.length} patients',
                                fontSize: 14,
                                color: AppColors.textSecondary,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    sliver: _filteredPatients.isEmpty
                        ? SliverToBoxAdapter(
                            child: Center(
                              child: Padding(
                                padding: EdgeInsets.only(top: Get.height / 4.2),
                                child: CustomText.bold(
                                  'No patients found',
                                  fontSize: 22,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                            ),
                          )
                        : SliverList(
                            delegate: SliverChildBuilderDelegate((
                              context,
                              index,
                            ) {
                              final patient = _filteredPatients[index];
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 12),
                                child: GestureDetector(
                                  onTap: () => Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => RecorderScreen(
                                        patientName: patient.userName,
                                        patientMRN: patient.mrn,
                                      ),
                                    ),
                                  ),
                                  child: _buildPatientCard(patient),
                                ),
                              );
                            }, childCount: _filteredPatients.length),
                          ),
                  ),
                  const SliverToBoxAdapter(child: SizedBox(height: 24)),
                ],
              ),
      ),
    );
  }

  Widget _buildFilterChip(String label, int count) {
    final isSelected = _filterCriteria == label;
    return GestureDetector(
      onTap: () => setState(() => _filterCriteria = label),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: AppColors.primary.withOpacity(0.3),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ]
              : [],
        ),
        child: Row(
          children: [
            CustomText.semiBold(
              label,
              fontSize: 14,
              color: isSelected ? Colors.white : AppColors.textPrimary,
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: isSelected
                    ? Colors.white.withOpacity(0.2)
                    : AppColors.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: CustomText.semiBold(
                count.toString(),
                fontSize: 12,
                color: isSelected ? Colors.white : AppColors.primary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPatientCard(Patient patient) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE5E5EA), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.person_outline, color: AppColors.primary, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: CustomText.bold(
                  patient.userName,
                  fontSize: 16,
                  color: const Color(0xFF1C1C1E),
                ),
              ),
              CustomText.medium(
                '${patient.sex} / ${patient.age}y',
                fontSize: 13,
                color: const Color(0xFF8E8E93),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _buildInfoRow('CONCERN:', patient.areaOfConcern),
          _buildInfoRow('MRN:', patient.mrn),
          _buildInfoRow('Contact:', patient.phoneNo),

          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _buildVital(
                  Icons.favorite,
                  Color(0xFFFF3B30),
                  'BP: ${patient.bloodPressure}',
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _buildVital(
                  Icons.favorite,
                  Color(0xFFFF2D55),
                  'HR: ${patient.heartRate}',
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: _buildVital(
                  Icons.thermostat,
                  Color(0xFFFF9500),
                  'Temp: ${patient.temperature}',
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _buildVital(
                  Icons.water_drop,
                  Color(0xFF007AFF),
                  'SpO₂: ${patient.oxygenLevel}',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          CustomText.semiBold(
            label,
            fontSize: 12,
            color: const Color(0xFF3C3C43),
          ),
          const SizedBox(width: 4),
          Expanded(
            child: CustomText.regular(
              value,
              fontSize: 12,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              color: const Color(0xFF8E8E93),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVital(IconData icon, Color color, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFF2F2F7),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 14),
          const SizedBox(width: 4),
          Flexible(
            child: CustomText.medium(
              text,
              fontSize: 12,
              color: const Color(0xFF3C3C43),
            ),
          ),
        ],
      ),
    );
  }
}
