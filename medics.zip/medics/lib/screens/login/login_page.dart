import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:medics/constant/colors.dart';
import 'package:medics/constant/svg_icon.dart';
import 'package:medics/controllers/auth_controller.dart';
import 'package:medics/screens/nav_screen/nav_screen.dart';
import 'package:medics/service/api_service.dart';
import 'package:medics/widgets/custom_app_bar.dart';
import 'package:medics/widgets/custom_text.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  final _phoneController = TextEditingController();
  final _otpController = TextEditingController();
  final _phoneFocusNode = FocusNode();
  final _otpFocusNode = FocusNode();

  bool _otpSent = false;
  bool _isLoading = false;
  int _resendTimer = 0;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _animationController.forward();
  }

  Timer? _timer;
  void _startResendTimer() {
    setState(() => _resendTimer = 30);
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_resendTimer > 0) {
        setState(() => _resendTimer--);
      } else {
        timer.cancel();
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _phoneController.dispose();
    _otpController.dispose();
    _phoneFocusNode.dispose();
    _otpFocusNode.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _sendOtp() async {
    if (_phoneController.text.length < 10) {
      _showSnackbar('Please enter a valid phone number');
      return;
    }

    setState(() => _isLoading = true);
    await ApiService.sendOtp(mobileNo: _phoneController.text);
    setState(() {
      _isLoading = false;
      _otpSent = true;
    });
    _startResendTimer();
    _otpFocusNode.requestFocus();
    _showSnackbar('OTP sent successfully!', isError: false);
  }

  Future<void> _verifyOtp() async {
    if (_otpController.text.length < 4) {
      _showSnackbar('Please enter a valid 4-digit OTP');
      return;
    }
    setState(() => _isLoading = true);

    try {
      final response = await ApiService.verifyOtp(
        mobileNo: _phoneController.text,
        otp: _otpController.text,
      );
      if (response.isNotEmpty) {
        AuthController.instance.login(
          response['doctorID'],
          response['hospitalID'],
        );
      }
      if (!mounted) return;

      await Future.delayed(const Duration(milliseconds: 100));

      if (!mounted) return;

      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const NavScreen()),
        (_) => false,
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      _showSnackbar('Verification failed. Please try again.');
    }
  }

  void _showSnackbar(String message, {bool isError = true}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: CustomText.medium(
          message,
          color: AppColors.surface,
          fontSize: 14,
        ),
        backgroundColor: isError ? AppColors.error : AppColors.success,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: CustomAppBar(title: 'Login'),
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 40),
                CustomText.bold(
                  'Welcome Back!',
                  fontSize: 28,
                  color: AppColors.textPrimary,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                CustomText.regular(
                  'Login to continue your health journey',
                  fontSize: 16,
                  color: AppColors.textSecondary,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 48),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.primary.withOpacity(0.08),
                        blurRadius: 24,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText.semiBold(
                        'Phone Number',
                        fontSize: 14,
                        color: AppColors.textPrimary,
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _phoneController,
                        focusNode: _phoneFocusNode,
                        enabled: !_otpSent,
                        keyboardType: TextInputType.phone,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                          LengthLimitingTextInputFormatter(10),
                        ],
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                          letterSpacing: 1.5,
                        ),
                        decoration: InputDecoration(
                          hintText: '9876543210',
                          hintStyle: TextStyle(
                            color: AppColors.textHint,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            letterSpacing: 1.5,
                          ),
                          prefixIcon: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                CustomText.semiBold(
                                  '+91',
                                  fontSize: 16,
                                  color: AppColors.textPrimary,
                                ),
                                const SizedBox(width: 8),
                                Container(
                                  width: 1,
                                  height: 24,
                                  color: AppColors.divider,
                                ),
                              ],
                            ),
                          ),
                          suffixIcon: _otpSent
                              ? IconButton(
                                  icon: Icon(
                                    Icons.edit_outlined,
                                    color: AppColors.primary,
                                    size: 20,
                                  ),
                                  onPressed: () {
                                    setState(() {
                                      _otpSent = false;
                                      _otpController.clear();
                                      _resendTimer = 0;
                                    });
                                    _phoneFocusNode.requestFocus();
                                  },
                                )
                              : null,
                          filled: true,
                          fillColor: _otpSent
                              ? AppColors.background
                              : AppColors.surface,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 20,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: BorderSide(color: AppColors.border),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: BorderSide(color: AppColors.border),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: BorderSide(
                              color: AppColors.primary,
                              width: 2,
                            ),
                          ),
                          disabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: BorderSide(color: AppColors.divider),
                          ),
                        ),
                      ),
                      if (_otpSent) ...[
                        const SizedBox(height: 24),
                        CustomText.semiBold(
                          'Enter OTP',
                          fontSize: 14,
                          color: AppColors.textPrimary,
                        ),
                        const SizedBox(height: 12),
                        PinCodeTextField(
                          backgroundColor: Colors.transparent,
                          length: 4,
                          controller: _otpController,
                          focusNode: _otpFocusNode,
                          keyboardType: TextInputType.number,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                            LengthLimitingTextInputFormatter(4),
                          ],
                          pinTheme: PinTheme(
                            shape: PinCodeFieldShape.box,
                            borderRadius: BorderRadius.circular(12),
                            fieldHeight: 56,
                            fieldWidth: 56,
                            activeFillColor: AppColors.surface,
                            inactiveFillColor: AppColors.surface,
                            selectedFillColor: AppColors.surface,
                            activeColor: AppColors.primary,
                            inactiveColor: AppColors.border,
                            selectedColor: AppColors.primary,
                            borderWidth: 1.5,
                          ),
                          enableActiveFill: true,
                          autoDismissKeyboard: true,
                          textStyle: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary,
                          ),
                          onChanged: (value) {},
                          onCompleted: (value) {
                            if (value.length == 6) _verifyOtp();
                          },
                          appContext: context,
                        ),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText.regular(
                              'Didn\'t receive code?',
                              fontSize: 14,
                              color: AppColors.textSecondary,
                            ),
                            TextButton(
                              onPressed: _resendTimer == 0 ? _sendOtp : null,
                              style: TextButton.styleFrom(
                                padding: EdgeInsets.zero,
                                minimumSize: const Size(0, 0),
                                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                              ),
                              child: CustomText.semiBold(
                                _resendTimer > 0
                                    ? 'Resend in ${_resendTimer}s'
                                    : 'Resend OTP',
                                fontSize: 14,
                                color: _resendTimer > 0
                                    ? AppColors.disabled
                                    : AppColors.primary,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 32),
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: ElevatedButton(
                    onPressed: _isLoading
                        ? null
                        : (_otpSent ? _verifyOtp : _sendOtp),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      disabledBackgroundColor: AppColors.disabled,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(32),
                      ),
                      elevation: 0,
                      shadowColor: AppColors.primary.withOpacity(0.4),
                    ),
                    child: _isLoading
                        ? SizedBox(
                            height: 24,
                            width: 24,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.5,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                AppColors.surface,
                              ),
                            ),
                          )
                        : CustomText.bold(
                            _otpSent ? 'Verify & Login' : 'Send OTP',
                            color: AppColors.surface,
                            fontSize: 16,
                          ),
                  ),
                ),
                const SizedBox(height: 32),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        height: 1,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.transparent, AppColors.divider],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: CustomText.medium(
                        'OR',
                        color: AppColors.textSecondary,
                        fontSize: 13,
                      ),
                    ),
                    Expanded(
                      child: Container(
                        height: 1,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [AppColors.divider, Colors.transparent],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 32),
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: OutlinedButton(
                    onPressed: () {},
                    style: OutlinedButton.styleFrom(
                      backgroundColor: AppColors.surface,
                      side: BorderSide(color: AppColors.border, width: 1.5),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(32),
                      ),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 16,
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SvgPicture.string(
                          SvgIcon.googleIcon,
                          width: 24,
                          height: 24,
                        ),
                        const SizedBox(width: 12),
                        CustomText.semiBold(
                          'Continue with Google',
                          color: AppColors.textPrimary,
                          fontSize: 16,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 40),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText.regular(
                      "Don't have an account? ",
                      color: AppColors.textSecondary,
                      fontSize: 14,
                    ),
                    TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom(
                        padding: EdgeInsets.zero,
                        minimumSize: const Size(0, 0),
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                      child: CustomText.bold(
                        'Sign Up',
                        color: AppColors.primary,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
