class Assets {
  static const String logo = 'assets/images/logo.png';
}
