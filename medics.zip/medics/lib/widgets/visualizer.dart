import 'dart:math';
import 'package:flutter/material.dart';
import 'package:medics/constant/colors.dart';

class VoiceVisualizer extends StatefulWidget {
  final List<double> amplitudes;
  final bool isRecording;

  const VoiceVisualizer({
    super.key,
    required this.amplitudes,
    required this.isRecording,
  });

  @override
  State<VoiceVisualizer> createState() => _VoiceVisualizerState();
}

class _VoiceVisualizerState extends State<VoiceVisualizer>
    with TickerProviderStateMixin {
  late AnimationController _rotationController;
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _rotationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 30),
    )..repeat();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();
  }

  @override
  void dispose() {
    _rotationController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([_rotationController, _pulseController]),
      builder: (_, __) {
        return CustomPaint(
          size: const Size(240, 240),
          painter: VoiceVisualizerPainter(
            amplitudes: widget.amplitudes,
            isRecording: widget.isRecording,
            rotationValue: _rotationController.value,
            pulseValue: _pulseController.value,
          ),
        );
      },
    );
  }
}

class VoiceVisualizerPainter extends CustomPainter {
  final List<double> amplitudes;
  final bool isRecording;
  final double rotationValue;
  final double pulseValue;

  const VoiceVisualizerPainter({
    required this.amplitudes,
    required this.isRecording,
    required this.rotationValue,
    required this.pulseValue,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final maxRadius = size.width * 0.5;

    canvas.save();
    canvas.translate(center.dx, center.dy);

    // ---------- amplitude ----------
    final double amp = isRecording && amplitudes.isNotEmpty
        ? amplitudes.reduce(max).clamp(0.0, 1.0)
        : 0.0;

    final double rotation = rotationValue * 2 * pi;
    final double pulse = sin(pulseValue * 2 * pi);

    final double baseRadius = maxRadius * 0.75;
    final double radius = baseRadius * (1.0 + pulse * 0.06 + amp * 0.2);
    final double thickness = 3.0 + amp * 3.0 + pulse * 0.8;

    // -----------------------------------------------------------------
    // 1. Build a *smooth* radius array (240 points)
    // -----------------------------------------------------------------
    const int segments = 240;
    final List<double> radii = List.filled(segments + 1, 0.0);

    // ---- raw wave (capped) -----------------------------------------
    for (int i = 0; i <= segments; i++) {
      final t = i / segments;
      final primary = sin(t * 6 + rotation * 0.8);
      final secondary = cos(t * 18 - pulseValue * 10) * 0.4;
      final mod = sin(t * 3 + rotation * 1.2) * 0.5 + 0.5;

      final raw = (primary + secondary) * mod; // -1 … 1
      final waveIntensity = isRecording ? 5 + amp * 12 : 3; // softer
      final wave = (raw * waveIntensity).clamp(-waveIntensity, waveIntensity);
      radii[i] = radius + wave;
    }

    // ---- 5-point Gaussian smoothing -------------------------------
    final smoothed = List<double>.from(radii);
    for (int i = 2; i < segments - 1; i++) {
      smoothed[i] =
          (radii[i - 2] +
              radii[i - 1] * 2 +
              radii[i] * 4 +
              radii[i + 1] * 2 +
              radii[i + 2]) /
          10;
    }
    // keep first/last untouched (they will be overlapped later)
    smoothed[0] = radii[0];
    smoothed[segments] = radii[segments];

    // -----------------------------------------------------------------
    // 2. Build a *closed* polygon (overlap first point)
    // -----------------------------------------------------------------
    final List<Offset> points = [];
    for (int i = 0; i <= segments; i++) {
      final t = i / segments;
      final angle = t * 2 * pi + rotation * 0.3;
      final r = smoothed[i];
      points.add(Offset(cos(angle) * r, sin(angle) * r));
    }

    // guarantee a perfect seam: repeat the first point at the end
    points.add(points.first);

    final path = Path()..addPolygon(points, true); // true → closed

    // -----------------------------------------------------------------
    // 3. Paints – strokeJoin = round + larger shader rect
    // -----------------------------------------------------------------
    final gradientPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = thickness
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..shader =
          SweepGradient(
            colors: const [
              AppColors.primary,
              Color(0xFF00E5FF),
              Color(0xFF00B0FF),
              AppColors.primary,
            ],
            stops: const [0.0, 0.45, 0.78, 1.0],
            transform: GradientRotation(rotation * 0.5),
          ).createShader(
            Rect.fromCircle(center: Offset.zero, radius: radius * 1.25),
          );

    // outer glow – draw on a 8 % bigger path
    final List<Offset> outerPoints = points
        .map((p) => Offset(p.dx * 1.08, p.dy * 1.08))
        .toList();
    final outerPath = Path()..addPolygon(outerPoints, true);

    final outerGlowPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = thickness * 3.5
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..color = AppColors.primary.withOpacity(0.35 + amp * 0.4)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 18 + amp * 22);

    // inner & outer auras
    final innerGlowPaint = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 35)
      ..shader =
          RadialGradient(
            colors: [
              AppColors.primary.withOpacity(0.55 + amp * 0.4),
              const Color(0xFF00E5FF).withOpacity(0.35 + amp * 0.3),
              Colors.transparent,
            ],
            stops: const [0.0, 0.7, 1.0],
          ).createShader(
            Rect.fromCircle(center: Offset.zero, radius: maxRadius * 0.9),
          );

    final outerAuraPaint = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 45)
      ..shader =
          RadialGradient(
            colors: [
              AppColors.primary.withOpacity(0.25 + amp * 0.25),
              const Color(0xFF00E5FF).withOpacity(0.15 + amp * 0.15),
              Colors.transparent,
            ],
            stops: const [0.6, 0.9, 1.0],
          ).createShader(
            Rect.fromCircle(center: Offset.zero, radius: maxRadius * 1.4),
          );

    // -----------------------------------------------------------------
    // 4. Draw order
    // -----------------------------------------------------------------
    canvas.drawPath(outerPath, outerGlowPaint);
    canvas.drawPath(path, gradientPaint);
    canvas.drawCircle(Offset.zero, maxRadius * 0.85, innerGlowPaint);
    canvas.drawCircle(Offset.zero, maxRadius * 1.2, outerAuraPaint);

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => true;
}
