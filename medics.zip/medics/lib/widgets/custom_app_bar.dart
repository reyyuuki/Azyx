import 'package:flutter/material.dart';
import 'package:medics/widgets/custom_text.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final IconData? icon;
  final bool centerTitle;
  const CustomAppBar({
    super.key,
    required this.title,
    this.icon,
    this.centerTitle = true,
  });

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: CustomText.bold(title, fontSize: 26, color: Colors.black),
      centerTitle: centerTitle,
      leading: Icon(icon ?? Icons.arrow_back_ios, color: Colors.black),
    );
  }

  @override
  Size get preferredSize =>
      Size(double.maxFinite, AppBar().preferredSize.height);
}
