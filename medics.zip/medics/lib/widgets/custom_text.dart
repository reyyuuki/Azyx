import 'package:flutter/material.dart';

enum CustomTextVariant { medium, regular, semiBold, bold }

class CustomText extends StatelessWidget {
  final String text;
  final CustomTextVariant variant;
  final double? fontSize;
  final Color? color;
  final TextAlign? textAlign;
  final int? maxLines;
  final TextOverflow? overflow;
  final double? height;
  final double? letterSpacing;
  final TextDecoration? decoration;
  final bool marquee;
  final Duration? marqueeDuration;
  final Curve? marqueeCurve;
  final FontStyle fontStyle;

  const CustomText(
    this.text, {
    super.key,
    this.variant = CustomTextVariant.regular,
    this.fontSize,
    this.color,
    this.textAlign,
    this.maxLines,
    this.overflow,
    this.height,
    this.letterSpacing,
    this.decoration,
    this.marquee = false,
    this.marqueeDuration,
    this.marqueeCurve,
    this.fontStyle = FontStyle.normal,
  });

  const CustomText.regular(
    this.text, {
    super.key,
    this.fontSize,
    this.color,
    this.textAlign,
    this.maxLines,
    this.overflow,
    this.height,
    this.letterSpacing,
    this.decoration,
    this.marquee = false,
    this.marqueeDuration,
    this.marqueeCurve,
    this.fontStyle = FontStyle.normal,
  }) : variant = CustomTextVariant.regular;

  const CustomText.medium(
    this.text, {
    super.key,
    this.fontSize,
    this.color,
    this.textAlign,
    this.maxLines,
    this.overflow,
    this.height,
    this.letterSpacing,
    this.decoration,
    this.marquee = false,
    this.marqueeDuration,
    this.marqueeCurve,
    this.fontStyle = FontStyle.normal,
  }) : variant = CustomTextVariant.medium;

  const CustomText.semiBold(
    this.text, {
    super.key,
    this.fontSize,
    this.color,
    this.textAlign,
    this.maxLines,
    this.overflow,
    this.height,
    this.letterSpacing,
    this.decoration,
    this.marquee = false,
    this.marqueeDuration,
    this.marqueeCurve,
    this.fontStyle = FontStyle.normal,
  }) : variant = CustomTextVariant.semiBold;

  const CustomText.bold(
    this.text, {
    super.key,
    this.fontSize,
    this.color,
    this.textAlign,
    this.maxLines,
    this.overflow,
    this.height,
    this.letterSpacing,
    this.decoration,
    this.marquee = false,
    this.marqueeDuration,
    this.marqueeCurve,
    this.fontStyle = FontStyle.normal,
  }) : variant = CustomTextVariant.bold;

  @override
  Widget build(BuildContext context) {
    String fontFamily;

    switch (variant) {
      case CustomTextVariant.regular:
        fontFamily = 'Poppins';
        break;
      case CustomTextVariant.semiBold:
        fontFamily = 'Poppins-SemiBold';
        break;
      case CustomTextVariant.bold:
        fontFamily = 'Poppins-Bold';
        break;
      case CustomTextVariant.medium:
        fontFamily = 'Poppins-Medium';
        break;
    }

    final textWidget = Text(
      text,
      textAlign: textAlign,
      maxLines: maxLines,
      overflow: overflow,
      style: TextStyle(
        fontFamily: fontFamily,
        fontSize: fontSize,
        color: color,
        height: height,
        letterSpacing: letterSpacing,
        decoration: decoration,
        fontStyle: fontStyle,
      ),
    );

    if (!marquee) {
      return textWidget;
    }

    return _MarqueeText(
      duration: marqueeDuration ?? const Duration(seconds: 5),
      curve: marqueeCurve ?? Curves.easeInOut,
      child: textWidget,
    );
  }
}

class _MarqueeText extends StatefulWidget {
  final Widget child;
  final Duration duration;
  final Curve curve;

  const _MarqueeText({
    required this.child,
    required this.duration,
    required this.curve,
  });

  @override
  State<_MarqueeText> createState() => _MarqueeTextState();
}

class _MarqueeTextState extends State<_MarqueeText>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: widget.duration, vsync: this);
    _animation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: widget.curve));
    _controller.repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return ClipRect(
          child: AnimatedBuilder(
            animation: _animation,
            builder: (context, child) {
              return OverflowBox(
                alignment: Alignment.centerLeft,
                maxWidth: double.infinity,
                child: Transform.translate(
                  offset: Offset(
                    -_animation.value * constraints.maxWidth * 0.5,
                    0,
                  ),
                  child: widget.child,
                ),
              );
            },
          ),
        );
      },
    );
  }
}
