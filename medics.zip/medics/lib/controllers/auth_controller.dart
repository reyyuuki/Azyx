import 'dart:developer';

import 'package:get/get.dart';
import 'package:medics/database/database.dart';
import 'package:medics/database/keys/data_keys.dart';

class AuthController extends GetxController {
  static AuthController get instance => Get.find();
  Rx<String> doctorId = ''.obs;
  Rx<String> hospitalId = ''.obs;
  Rx<bool> loggedIn = false.obs;

  @override
  void onInit() {
    super.onInit();
    init();
  }

  void init() async {
    doctorId.value = await DataKeys.doctorId.get('');
    hospitalId.value = await DataKeys.hospitalId.get('');
    loggedIn.value = await DataKeys.loggedIn.get(false);
  }

  void login(String doctorId, String hospitalId) {
    DataKeys.doctorId.set(doctorId);
    DataKeys.hospitalId.set(hospitalId);
    DataKeys.loggedIn.set(true);
    log('doctorId: $doctorId, hospitalId: $hospitalId, loggedIn: $loggedIn');
    this.doctorId.value = doctorId;
    this.hospitalId.value = hospitalId;
    loggedIn.value = true;
  }

  void logout() {
    DataKeys.doctorId.set('');
    DataKeys.hospitalId.set('');
    DataKeys.loggedIn.set(false);

    doctorId.value = '';
    hospitalId.value = '';
    loggedIn.value = false;
  }
}
