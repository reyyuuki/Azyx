class Patient {
  final String userID;
  final String userName;
  final String mobileNo;
  final String gender;
  final String age;
  final String dob;
  final String bloodGroup;
  final String hospitalID;
  final String doctorID;
  final String appointmentDate;
  final String mappingStatus;
  final String phoneNo;
  final String areaOfConcern;
  final String weight;
  final String heartRate;
  final String oxygenLevel;
  final String temperature;
  final String bloodPressure;
  final String mrn;

  Patient({
    required this.userID,
    required this.userName,
    required this.mobileNo,
    required this.gender,
    required this.age,
    required this.dob,
    required this.bloodGroup,
    required this.hospitalID,
    required this.doctorID,
    required this.appointmentDate,
    required this.mappingStatus,
    required this.phoneNo,
    required this.areaOfConcern,
    required this.weight,
    required this.heartRate,
    required this.oxygenLevel,
    required this.temperature,
    required this.bloodPressure,
    required this.mrn,
  });

  factory Patient.fromJson(Map<String, dynamic> json) {
    return Patient(
      areaOfConcern: json['areaOfConcern'] ?? '',
      phoneNo: json['mobileNo'] ?? '',
      userID: json['userID'] ?? '',
      userName: json['userName'] ?? '',
      mobileNo: json['mobileNo'] ?? '',
      gender: json['gender'] ?? '',
      age: json['age'] ?? '',
      dob: json['dob'] ?? '',
      bloodGroup: json['bloodGroup'] ?? '',
      hospitalID: json['hospitalID'] ?? '',
      doctorID: json['doctorID'] ?? '',
      appointmentDate: json['appointmentDate'] ?? '',
      mappingStatus: json['mappingStatus'] ?? '',
      weight: json['weight'] ?? '',
      heartRate: json['heartRate'] ?? '',
      oxygenLevel: json['oxygenLevel'] ?? '',
      temperature: json['temperature'] ?? '',
      bloodPressure: json['bloodPressure'] ?? '',
      mrn: json['mrn'] ?? '',
    );
  }

  String get sex => gender.toUpperCase() == 'MALE' ? 'M' : 'F';
  String get formattedMRN =>
      userID.startsWith('PAT_') ? userID.replaceAll('PAT_', 'MRN-') : mrn;
}
