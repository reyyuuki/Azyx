import 'dart:developer';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:medics/service/api_service.dart';

class Recording {
  final String id;
  final String filePath;
  final Duration duration;
  final DateTime timestamp;
  final String patientName;
  final String patientMRN;
  final String title;
  String? uploadUrl;
  String? fileKey;
  bool isUploaded;

  Recording({
    required this.id,
    required this.filePath,
    required this.duration,
    required this.timestamp,
    required this.patientName,
    required this.patientMRN,
    required this.title,
    this.uploadUrl,
    this.fileKey,
    this.isUploaded = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'filePath': filePath,
      'duration': duration.inSeconds,
      'timestamp': timestamp.millisecondsSinceEpoch,
      'patientName': patientName,
      'patientMRN': patientMRN,
      'title': title,
      'uploadUrl': uploadUrl,
      'fileKey': fileKey,
      'isUploaded': isUploaded,
    };
  }

  factory Recording.fromMap(Map<dynamic, dynamic> map) {
    return Recording(
      id: map['id'] as String,
      filePath: map['filePath'] as String,
      duration: Duration(seconds: map['duration'] as int),
      timestamp: DateTime.fromMillisecondsSinceEpoch(map['timestamp'] as int),
      patientName: map['patientName'] as String,
      patientMRN: map['patientMRN'] as String,
      title: map['title'] as String,
      uploadUrl: map['uploadUrl'] as String?,
      fileKey: map['fileKey'] as String?,
      isUploaded: map['isUploaded'] as bool? ?? false,
    );
  }

  Future<void> generateUploadUrl() async {
    try {
      final response = await ApiService.generatePresignedUrl(
        type: 'PATIENT_AUDIO',
        mimeType: 'audio/aac',
        key: patientMRN,
      );

      // The API returns: {"response": {...}, "url": "..."}
      // We need the "url" field
      if (response['url'] == null || response['url'].toString().isEmpty) {
        throw Exception('Invalid response: missing url field');
      }

      uploadUrl = response['url'] as String;
      fileKey = patientMRN;
      log('aando: $patientMRN');
    } catch (e) {
      throw Exception('Failed to generate upload URL: $e');
    }
  }

  Future<void> uploadRecording() async {
    // Generate URL if not already present
    if (uploadUrl == null || uploadUrl!.isEmpty) {
      await generateUploadUrl();
    }

    // Double-check after generation attempt
    if (uploadUrl == null || uploadUrl!.isEmpty) {
      throw Exception('Upload URL is still null after generation attempt');
    }

    try {
      final file = File(filePath);

      // Check if file exists
      if (!await file.exists()) {
        throw Exception('Recording file not found at: $filePath');
      }

      final bytes = await file.readAsBytes();

      // Validate bytes
      if (bytes.isEmpty) {
        throw Exception('Recording file is empty');
      }

      final response = await http.put(
        Uri.parse(uploadUrl!),
        headers: {'Content-Type': 'audio/aac'},
        body: bytes,
      );

      if (response.statusCode == 200) {
        isUploaded = true;
        await ApiService().generateMedicReport(
          mrn: patientMRN,
          name: patientName,
        );
      } else {
        throw Exception(
          'Upload failed with status ${response.statusCode}: ${response.body}',
        );
      }
    } catch (e) {
      throw Exception('Failed to upload recording: $e');
    }
  }
}
