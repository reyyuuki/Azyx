import 'package:flutter/material.dart';
import 'dart:math';

class WaveformPainter extends CustomPainter {
  final List<double> waveformData;
  final Color color;
  final bool isRecording;
  final double animation;

  WaveformPainter({
    required this.waveformData,
    required this.color,
    required this.isRecording,
    required this.animation,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    final barWidth = size.width / waveformData.length;
    final centerY = size.height / 2;

    for (int i = 0; i < waveformData.length; i++) {
      final x = i * barWidth + barWidth / 2;

      // Calculate bar height based on amplitude
      double barHeight = waveformData[i] * size.height * 0.8;

      // Add animation effect when recording
      if (isRecording) {
        final animationOffset = sin((animation * 2 * pi) + (i * 0.2));
        barHeight += animationOffset * 5;
      }

      // Ensure minimum bar height for visual effect
      barHeight = max(barHeight, 4);

      // Draw the bar (centered vertically)
      final path = Path();
      path.moveTo(x, centerY - barHeight / 2);
      path.lineTo(x, centerY + barHeight / 2);

      canvas.drawPath(path, paint);
    }

    // Draw center line when not recording
    if (!isRecording) {
      final linePaint = Paint()
        ..color = color.withOpacity(0.2)
        ..strokeWidth = 1;

      canvas.drawLine(
        Offset(0, centerY),
        Offset(size.width, centerY),
        linePaint,
      );
    }
  }

  @override
  bool shouldRepaint(WaveformPainter oldDelegate) {
    return oldDelegate.waveformData != waveformData ||
        oldDelegate.isRecording != isRecording ||
        oldDelegate.animation != animation;
  }
}
