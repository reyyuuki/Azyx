import 'package:flutter/material.dart';
import 'package:medics/constant/colors.dart';
import 'package:medics/service/api_service.dart';
import 'package:medics/widgets/custom_text.dart';

class ApiTestScreen extends StatefulWidget {
  const ApiTestScreen({super.key});

  @override
  State<ApiTestScreen> createState() => _ApiTestScreenState();
}

class _ApiTestScreenState extends State<ApiTestScreen> {
  bool _isLoading = false;
  String _result = '';

  final _nameController = TextEditingController(text: 'John Doe');
  final _mobileController = TextEditingController(text: '9876543210');
  final _genderController = TextEditingController(text: 'MALE');
  final _ageController = TextEditingController(text: '30');
  final _dobController = TextEditingController(text: '1993-05-15');
  final _bloodGroupController = TextEditingController(text: 'O+');
  final _hospitalIDController = TextEditingController(text: 'HOSP_001');
  final _doctorIDController = TextEditingController(text: 'DOC_001');
  final _appointmentDateController = TextEditingController(text: '2024-01-15');

  Future<void> _testHandlePatientDetails() async {
    setState(() {
      _isLoading = true;
      _result = '';
    });

    try {
      final response = await ApiService.handlePatientDetails(
        userName: _nameController.text,
        mobileNo: _mobileController.text,
        gender: _genderController.text,
        age: _ageController.text,
        dob: _dobController.text,
        bloodGroup: _bloodGroupController.text,
        hospitalID: _hospitalIDController.text,
        reportingDoctorID: _doctorIDController.text,
        appointmentDate: _appointmentDateController.text,
      );

      setState(() {
        _result = 'Success!\n\n${response.toString()}';
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _result = 'Error: $e';
        _isLoading = false;
      });
    }
  }

  // Future<void> _testFetchPatientList() async {
  //   setState(() {
  //     _isLoading = true;
  //     _result = '';
  //   });

  //   try {
  //     final patients = await ApiService.fetchPatientList(
  //       hospitalID: _hospitalIDController.text,
  //     );

  //     setState(() {
  //       _result = 'Success! Found ${patients.patients.length} patients:\n\n';
  //       for (var patient in patients.patients) {
  //         _result += '${patient.userName} (${patient.userID})\n';
  //         _result += 'Age: ${patient.age}, Gender: ${patient.gender}\n';
  //         _result += 'Mobile: ${patient.mobileNo}\n\n';
  //       }
  //       _isLoading = false;
  //     });
  //   } catch (e) {
  //     setState(() {
  //       _result = 'Error: $e';
  //       _isLoading = false;
  //     });
  //   }
  // }

  // Future<void> _testGeneratePresignedUrl() async {
  //   setState(() {
  //     _isLoading = true;
  //     _result = '';
  //   });

  //   try {
  //     final response = await ApiService.generatePresignedUrl(
  //       type: 'APPOINTMENT_RECORDING',
  //       mimeType: 'audio/mpeg',
  //       key: 'patient_123_consultation',
  //     );

  //     setState(() {
  //       _result = 'Success!\n\n';
  //       _result += 'Upload URL: ${response.uploadUrl}\n\n';
  //       _result += 'File Key: ${response.fileKey}';
  //       _isLoading = false;
  //     });
  //   } catch (e) {
  //     setState(() {
  //       _result = 'Error: $e';
  //       _isLoading = false;
  //     });
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        title: CustomText.semiBold(
          'API Test Screen',
          fontSize: 18,
          color: Colors.white,
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            CustomText.bold(
              'Patient Details Form',
              fontSize: 18,
              color: AppColors.textPrimary,
            ),
            const SizedBox(height: 16),
            _buildTextField('Name', _nameController),
            _buildTextField('Mobile', _mobileController),
            _buildTextField('Gender', _genderController),
            _buildTextField('Age', _ageController),
            _buildTextField('DOB', _dobController),
            _buildTextField('Blood Group', _bloodGroupController),
            _buildTextField('Hospital ID', _hospitalIDController),
            _buildTextField('Doctor ID', _doctorIDController),
            _buildTextField('Appointment Date', _appointmentDateController),
            const SizedBox(height: 24),
            CustomText.bold(
              'API Actions',
              fontSize: 18,
              color: AppColors.textPrimary,
            ),
            const SizedBox(height: 16),
            _buildActionButton(
              'Test Handle Patient Details',
              _testHandlePatientDetails,
              Colors.blue,
            ),
            const SizedBox(height: 12),
            _buildActionButton('Test Fetch Patient List', () {}, Colors.green),
            const SizedBox(height: 12),
            _buildActionButton(
              'Test Generate Presigned URL',
              () {},
              Colors.orange,
            ),
            const SizedBox(height: 24),
            if (_isLoading) const Center(child: CircularProgressIndicator()),
            if (_result.isNotEmpty) ...[
              CustomText.bold(
                'Result:',
                fontSize: 18,
                color: AppColors.textPrimary,
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey[300]!),
                ),
                child: SelectableText(
                  _result,
                  style: const TextStyle(fontSize: 13, fontFamily: 'monospace'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomText.medium(
            label,
            fontSize: 13,
            color: AppColors.textSecondary,
          ),
          const SizedBox(height: 6),
          TextField(
            controller: controller,
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: Colors.grey[300]!),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: Colors.grey[300]!),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: AppColors.primary),
              ),
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 12,
              ),
            ),
            style: const TextStyle(fontSize: 14),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton(String text, VoidCallback onPressed, Color color) {
    return ElevatedButton(
      onPressed: _isLoading ? null : onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        elevation: 2,
      ),
      child: CustomText.semiBold(text, fontSize: 15, color: Colors.white),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _mobileController.dispose();
    _genderController.dispose();
    _ageController.dispose();
    _dobController.dispose();
    _bloodGroupController.dispose();
    _hospitalIDController.dispose();
    _doctorIDController.dispose();
    _appointmentDateController.dispose();
    super.dispose();
  }
}
