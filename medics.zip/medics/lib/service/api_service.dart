import 'dart:convert';
import 'dart:developer';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:medics/models/patient.dart';

class ApiService {
  static const String baseUrl =
      'https://w54hm4svyk.execute-api.ap-south-1.amazonaws.com/medics_dev';

  // Replace your handlePatientDetails method with this:
  static Future<Map<String, dynamic>> handlePatientDetails({
    required String userName,
    required String mobileNo,
    required String gender,
    required String age,
    required String dob,
    required String bloodGroup,
    required String hospitalID,
    required String reportingDoctorID,
    required String appointmentDate,
  }) async {
    // FIXED: Removed '/patient' from the path
    final url = Uri.parse('$baseUrl/handle-patient-details');

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'userName': userName,
        'mobileNo': mobileNo,
        'gender': gender,
        'age': age,
        'dob': dob,
        'bloodGroup': bloodGroup,
        'hospitalID': hospitalID,
        'reportingDoctorID': reportingDoctorID,
        'appointmentDate': appointmentDate,
      }),
    );

    if (response.statusCode == 200) {
      log('Patient details handled successfully: ${response.body}');
      return jsonDecode(response.body);
    } else {
      log(
        'Failed to handle patient details: ${response.statusCode} - ${response.body}',
      );
      throw Exception(
        'Failed to handle patient details: ${response.statusCode}',
      );
    }
  }

  static Future<List<Patient>> fetchPatientList({
    required String hospitalID,
    required String doctorID,
  }) async {
    final url = Uri.parse('$baseUrl/fetch-patient-list');

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'hospitalID': hospitalID,
        'doctorID': doctorID,
        'appointmentDate': DateFormat(
          'yyyy-MM-dd',
        ).format(DateTime(2025, 10, 15)),
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      log(data['patients'].toString());
      final List patients = data['patients'] ?? [];
      return patients.map((json) => Patient.fromJson(json)).toList();
    } else {
      throw Exception('Failed to fetch patient list: ${response.statusCode}');
    }
  }

  static Future<void> sendOtp({required String mobileNo}) async {
    final url = Uri.parse('$baseUrl/send-otp');

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'mobileNo': mobileNo}),
    );

    if (response.statusCode == 200) {
      log('OTP sent successfully ${response.body}');
    } else {
      log('Failed to send OTP: ${response.statusCode}');
      throw Exception('Failed to send OTP: ${response.statusCode}');
    }
  }

  static Future<Map<String, dynamic>> verifyOtp({
    required String mobileNo,
    required String otp,
  }) async {
    final url = Uri.parse('$baseUrl/verify-otp');

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'mobileNo': mobileNo, 'otp': otp}),
    );

    if (response.statusCode == 200) {
      log('verify OTP successfully ${response.body}');
      return jsonDecode(response.body);
    } else {
      log('Failed to verify OTP: ${response.statusCode}');
      throw Exception('Failed to verify OTP: ${response.statusCode}');
    }
  }

  static Future<Map<String, dynamic>> generatePresignedUrl({
    required String type,
    required String mimeType,
    required String key,
  }) async {
    final url = Uri.parse('$baseUrl/generate-presigned-url');

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'type': type, 'mimeType': mimeType, 'key': key}),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      log('Failed to generate presigned URL: ${response.statusCode}');
      throw Exception(
        'Failed to generate presigned URL: ${response.statusCode}',
      );
    }
  }

  Future<void> generateMedicReport({
    required String mrn,
    required String name,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/generate-medical-report'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'mrn': mrn, 'name': name}),
      );
      if (response.statusCode == 200) {
        log('Report generated successfully ${response.body}');
      } else {
        log('Failed to generate report: ${response.statusCode}');
        throw Exception('Failed to generate report: ${response.statusCode}');
      }
    } catch (e) {
      log('Failed to generate report: ${e.toString()}');
    }
  }
}
