import 'package:hive_flutter/hive_flutter.dart';

class Database {
  static Box get box => Hive.box('database');
  static Future<void> init() async {
    await Hive.initFlutter();
    await Hive.openBox('database');
  }

  static Future<void> get<T>(String key, T defaultValue) async =>
      box.get(key, defaultValue: defaultValue);
  static Future<void> set<T>(String key, T value) async => box.put(key, value);
}

extension DataBaseEnum on Enum {
  get<T>(T defaultValue) => Database.get(name, defaultValue);
  set<T>(T value) => Database.set(name, value);
}
