enum DataKeys { hospitalId, doctorId, loggedIn }
