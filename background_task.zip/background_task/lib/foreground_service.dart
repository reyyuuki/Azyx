import 'dart:async';
import 'dart:developer';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:http/http.dart' as http;

class ForegroundTaskHandler extends TaskHandler {
  static const String apiUrl =
      'https://count.getloli.com/@ReyYuuki?name=ReyYuuki&theme=random&padding=7&offset=0&align=top&scale=1&pixelated=1&darkmode=auto';

  DateTime? _lastPingTime;
  static const Duration pingInterval = Duration(
    seconds: 5,
  ); // Changed to 5 seconds

  int _pingCount = 0;

  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {
    log('🚀 Foreground Service Started');
    _lastPingTime = null; // Reset to trigger immediate ping
  }

  @override
  void onRepeatEvent(DateTime timestamp) {
    log('⏰ onRepeatEvent called at ${DateTime.now()}'); // Debug log
    final now = DateTime.now();

    // Check if 5 seconds have passed
    if (_lastPingTime == null ||
        now.difference(_lastPingTime!) >= pingInterval) {
      _pingApi();
      _lastPingTime = now;
      _pingCount++;

      log('📊 Ping count: $_pingCount'); // Debug log

      // Send data to main isolate
      FlutterForegroundTask.sendDataToMain({
        'timestamp': now.toIso8601String(),
        'pingCount': _pingCount,
      });

      // Update notification
      FlutterForegroundTask.updateService(
        notificationTitle: '📡 API Pinger Active',
        notificationText:
            'Last ping: ${_formatTime(now)} | Total: $_pingCount pings',
      );
    }
  }

  @override
  Future<void> onDestroy(DateTime timestamp, bool isTimeout) async {
    log('🛑 Foreground Service Stopped');
    _lastPingTime = null;
  }

  Future<void> _pingApi() async {
    try {
      log('📡 Pinging API at ${DateTime.now()}');

      final response = await http
          .get(Uri.parse('https://api.github.com/users/reyyuuki'))
          .timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        log('✅ API Ping Success: ${response.statusCode}');
        log('Response Body: ${response.body}');
      } else {
        log('⚠️ API Ping Failed: ${response.statusCode}');
      }
    } catch (e) {
      log('❌ API Ping Error: $e');
    }
  }

  String _formatTime(DateTime time) {
    return '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}:${time.second.toString().padLeft(2, '0')}';
  }

  @override
  void onReceiveData(Object data) {
    log('📨 Received data: $data');
  }

  @override
  void onNotificationButtonPressed(String id) {
    // Handle notification button presses if needed
  }

  @override
  void onNotificationPressed() {
    FlutterForegroundTask.launchApp('/');
  }

  @override
  void onNotificationDismissed() {
    // Handle notification dismissal if needed
  }
}

class ForegroundServiceManager {
  static Future<bool> startService() async {
    if (await FlutterForegroundTask.isRunningService) {
      return true;
    }

    final result = await FlutterForegroundTask.startService(
      serviceId: 256,
      notificationTitle: '📡 API Pinger Active',
      notificationText: 'Pinging API every 5 seconds',
      callback: startCallback,
    );

    return switch (result) {
      ServiceRequestSuccess() => true,
      ServiceRequestFailure() => false,
    };
  }

  static Future<bool> stopService() async {
    final result = await FlutterForegroundTask.stopService();

    return switch (result) {
      ServiceRequestSuccess() => true,
      ServiceRequestFailure() => false,
    };
  }

  static Future<bool> isRunning() async {
    return await FlutterForegroundTask.isRunningService;
  }
}

@pragma('vm:entry-point')
void startCallback() {
  FlutterForegroundTask.setTaskHandler(ForegroundTaskHandler());
}
