import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'home_screen.dart';
import 'foreground_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Foreground Task
  FlutterForegroundTask.init(
    androidNotificationOptions: AndroidNotificationOptions(
      channelId: 'api_pinger_channel',
      channelName: 'API Pinger Service',
      channelDescription: 'Pings API every 5 seconds in background',
      channelImportance: NotificationChannelImportance.LOW,
      priority: NotificationPriority.LOW,
    ),
    iosNotificationOptions: const IOSNotificationOptions(
      showNotification: true,
      playSound: false,
    ),
    foregroundTaskOptions: ForegroundTaskOptions(
      // FIX: The interval is set in eventAction.repeat()
      eventAction: ForegroundTaskEventAction.repeat(5000), // 5000ms = 5 seconds
      autoRunOnBoot: false,
      allowWakeLock: true,
      allowWifiLock: false,
    ),
  );

  runApp(const MyApp());
}

@pragma('vm:entry-point')
void startCallback() {
  FlutterForegroundTask.setTaskHandler(ForegroundTaskHandler());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'API Pinger Demo',
      theme: ThemeData(primarySwatch: Colors.blue, useMaterial3: true),
      home: const WithForegroundTask(child: HomeScreen()),
    );
  }
}

class WithForegroundTask extends StatefulWidget {
  const WithForegroundTask({Key? key, required this.child}) : super(key: key);

  final Widget child;

  @override
  State<WithForegroundTask> createState() => _WithForegroundTaskState();
}

class _WithForegroundTaskState extends State<WithForegroundTask> {
  @override
  void initState() {
    super.initState();
    _initForegroundTask();
  }

  Future<void> _initForegroundTask() async {
    await FlutterForegroundTask.requestNotificationPermission();
  }

  @override
  Widget build(BuildContext context) {
    return widget.child;
  }
}
