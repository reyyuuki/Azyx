package com.example.background_task

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
